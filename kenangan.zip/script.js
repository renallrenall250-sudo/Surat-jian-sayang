// =======================
// MUSIK
// =======================

const music = document.getElementById("bgMusic");
const musicBtn = document.getElementById("musicBtn");
const disc = document.querySelector(".disc");

let playing = false;

musicBtn.addEventListener("click", () => {

    if (playing) {
        music.pause();
        disc.classList.add("pause");
        playing = false;
    } else {
        music.play();
        disc.classList.remove("pause");
        playing = true;
    }

});

// =======================
// BUKA KENANGAN
// =======================

const openBtn = document.getElementById("openBtn");

openBtn.addEventListener("click", () => {

    document.querySelector(".story-page")
    .scrollIntoView({
        behavior: "smooth"
    });

    if (!playing) {
        music.play();
        playing = true;
    }

});

// =======================
// FOTO STORY
// =======================

const photos = [

"",
"https://cdn.phototourl.com/free/2026-05-27-5808433a-4b94-4ba2-a621-7dfd243ef7a2.webp",
"https://cdn.phototourl.com/free/2026-05-27-f73cc85a-3049-4156-bfac-efa1162aad03.jpg",
"https://cdn.phototourl.com/free/2026-05-27-ea78b0de-dde5-4301-a950-62aa4fea0ece.jpg",
"https://cdn.phototourl.com/free/2026-05-27-18c97907-789c-4cc2-9ac2-9af7d3ac7915.jpg",
"https://cdn.phototourl.com/free/2026-05-27-71b1329c-fb66-4082-b1f6-179c6ce7fe7b.jpg",
"https://cdn.phototourl.com/member/2026-05-27-76db9bb8-ea92-4b8f-ac97-a6bec325f28a.jpg",
"https://cdn.phototourl.com/member/2026-05-27-7b842824-2cd8-4b8d-837e-50611cb6419f.jpg",
"https://cdn.phototourl.com/member/2026-05-27-3a3cfd13-b189-42e7-b889-68f17e2d9ee3.webp",
"https://cdn.phototourl.com/member/2026-05-27-1034bb90-2fb3-4410-a1e0-e8385402238c.jpg",
"https://cdn.phototourl.com/member/2026-05-27-c8f3f7c2-53f3-4fb9-8bfb-63a46aae8844.jpg",
"https://cdn.phototourl.com/free/2026-05-27-f73cc85a-3049-4156-bfac-efa1162aad03.jpg",
"https://cdn.phototourl.com/free/2026-05-27-5808433a-4b94-4ba2-a621-7dfd243ef7a2.webp",
"https://cdn.phototourl.com/free/2026-05-27-951d2859-dee2-46af-81a0-ab6a13889eb8.jpg",
"https://cdn.phototourl.com/free/2026-05-27-683b95c6-76ff-4ec9-b919-1e55a5700c01.jpg"

];

let current = 0;

const storyImage =
document.getElementById("storyImage");

const progressBar =
document.getElementById("progressBar");

function updateStory(){

    storyImage.src = photos[current];

    let percent =
    ((current + 1) / photos.length) * 100;

    progressBar.style.width =
    percent + "%";

}

document
.getElementById("nextBtn")
.addEventListener("click",()=>{

    current++;

    if(current >= photos.length){
        current = 0;
    }

    updateStory();

});

document
.getElementById("prevBtn")
.addEventListener("click",()=>{

    current--;

    if(current < 0){
        current = photos.length - 1;
    }

    updateStory();

});

// AUTO STORY

setInterval(()=>{

    current++;

    if(current >= photos.length){
        current = 0;
    }

    updateStory();

},5000);

// =======================
// SURAT KETIK
// =======================

const surat = `

sayaangggkuu cintakuuu maafinn apissss yaaaa karnaa apisss udahh gaasopann dan keterlaluann bangttt bercandannyaa apisss tauuu apisss tuu salahh bangett gaa aadaa adapp nyaaa.

padahalll mama kamuu udahh baikk samaa apissss baikk bangett malahhh tapiii apissss malahh kek gituuu.

besok besokk apisss gabakall pernahh kek gituu lagii kokk.

apisss harusnyaa seblum apaa aapaa mikirrr duluuu bukann langsungg ngomongg ajaaa.

apissss mintaaaa maafff yaaa sayaanggg mintaa maaaff ygg sebesarr besarrrnyaaaa.

gabakall ngulangiinyaaa lagii.

mungkinn apisss sakitt nii karnaaa karmaa mungkinn heehe.

maaff yaaaaa syaanggg.

maaff jugaaa yaaaa buatt mama kamuuu.

maafff sayangggg.

i lovee youuu 💟💟

`;

const typing =
document.getElementById("typing");

let i = 0;

function typeLetter(){

    if(i < surat.length){

        typing.innerHTML +=
        surat.charAt(i);

        i++;

        setTimeout(
            typeLetter,
            35
        );

    }

}

// =======================
// ANIMASI MASUK
// =======================

window.addEventListener("load",()=>{

    document.body.style.opacity = "0";

    setTimeout(()=>{

        document.body.style.transition =
        "1.5s";

        document.body.style.opacity =
        "1";

    },100);

    updateStory();

    setTimeout(()=>{
        typeLetter();
    },1500);

});

// =======================
// EFEK PARALLAX COVER
// =======================

window.addEventListener("scroll",()=>{

    const cover =
    document.querySelector(".cover");

    const value =
    window.scrollY * 0.3;

    cover.style.transform =
    `scale(1.1) translateY(${value}px)`;

});

// =======================
// KLIK FOTO FULLSCREEN
// =======================

storyImage.addEventListener("click",()=>{

    if(storyImage.requestFullscreen){

        storyImage.requestFullscreen();

    }

});